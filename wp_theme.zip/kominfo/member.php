<?php

/* Template Name: Member */ 




	


?>

<a href="<?php echo get_home_url();?>">Home</a> | 
<a href="/wp/buku">Buku</a> |
<a href="/wp/member">Member</a> | 
<a href="/wp/transaksi">Transaksi</a>
<h2>Member</h2>

<table border="1">
<tr>
	<td>Nama</td>
    <td>Alamat</td>
    <td>No. Handphone</td>
</tr>

<?php
global $wpdb;


$results = $wpdb->get_results(

    "SELECT * FROM tb_member"

);
foreach($results as $row)
{
	echo '<tr>';
	echo '<td>' . $row->nama . '</td>';
    echo '<td>' . $row->alamat .'</td>';
    echo '<td>' . $row->no_hp .'</td>';
	echo '</tr>';

}?>




</table>





