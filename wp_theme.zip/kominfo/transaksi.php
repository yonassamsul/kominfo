<?php

/* Template Name: Transaksi */ 




	


?>
<a href="<?php echo get_home_url();?>">Home</a> | 
<a href="/wp/buku">Buku</a> |
<a href="/wp/member">Member</a> | 
<a href="/wp/transaksi">Transaksi</a>
<h2>Transaksi</h2>

<table border="1">
<tr>
	<td>Judul buku</td>
    <td>Pengarang</td>
    <td>Penerbit</td>
    <td>Tahun</td>
    <td>ISBN</td>
</tr>

<?php
global $wpdb;


$results = $wpdb->get_results(

    "SELECT * FROM tb_transaksi"

);
foreach($results as $row)
{
	echo '<tr>';
	echo '<td>' . $row->id_member . '</td>';
    echo '<td>' . $row->id_buku .'</td>';
    echo '<td>' . $row->status .'</td>';
    echo '<td>' . $row->tanggal_pinjam . '</td>';
    echo '<td>' . $row->tanggal_kembali . '</td>';
	echo '</tr>';

}?>




</table>





