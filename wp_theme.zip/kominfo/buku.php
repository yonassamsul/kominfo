<?php

/* Template Name: Buku */ 




	


?>
<a href="<?php echo get_home_url();?>">Home</a> | 
<a href="/wp/buku">Buku</a> |
<a href="/wp/member">Member</a> | 
<a href="/wp/transaksi">Transaksi</a>
<h2>Buku</h2>

<table border="1">
<tr>
	<td>Judul buku</td>
    <td>Pengarang</td>
    <td>Penerbit</td>
    <td>Tahun</td>
    <td>ISBN</td>
</tr>

<?php
global $wpdb;


$results = $wpdb->get_results(

    "SELECT * FROM tb_buku"

);
foreach($results as $row)
{
	echo '<tr>';
	echo '<td>' . $row->judul . '</td>';
    echo '<td>' . $row->pengarang .'</td>';
    echo '<td>' . $row->penerbit .'</td>';
    echo '<td>' . $row->tahun . '</td>';
    echo '<td>' . $row->isbn . '</td>';
	echo '</tr>';

}?>




</table>





