<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Perpustakaan Kotamobagu</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap Icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
        <!-- SimpleLightbox plugin CSS-->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/SimpleLightbox/2.1.0/simpleLightbox.min.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="<?php echo get_template_directory_uri(); ?>/css/styles.css" rel="stylesheet" />
    </head>
<body>

<?php

/* Template Name: Buku */ 




	


?>
<a href="<?php echo get_home_url();?>">Home</a> | 
<a href="/wp/buku">Buku</a> |
<a href="/wp/member">Member</a> | 
<a href="/wp/transaksi">Transaksi</a>
<h2>Buku</h2>

<table border="1" class="table table-striped">
<tr>
	<td>Judul buku</td>
    <td>Pengarang</td>
    <td>Penerbit</td>
    <td>Tahun</td>
    <td>ISBN</td>
    <td>Operasi</td>
</tr>

<?php
global $wpdb;


$results = $wpdb->get_results(

    "SELECT * FROM tb_buku"

);
foreach($results as $row)
{
	echo '<tr>';
	echo '<td>' . $row->judul . '</td>';
    echo '<td>' . $row->pengarang .'</td>';
    echo '<td>' . $row->penerbit .'</td>';
    echo '<td>' . $row->tahun . '</td>';
    echo '<td>' . $row->isbn . '</td>';
	echo '<td><a href="?edit&id=' . $row->id . '">Edit</a> | <a href="?hapus&id='.$row->id.'">Hapus</a></td>';
	echo '</tr>';

}?>




</table>



</body>
</head>

